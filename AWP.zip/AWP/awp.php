<?php
/* Plugin Name: Aamir's Woo Plugin
 * Author: Aamir
 * Version: 1.0
 * Description: n/a
 **/
if ( ! class_exists( 'WC_custom_integration' ) ) :
class WC_custom_integration {
  /**
  * Construct the plugin.
  */
  public function __construct() {
    add_action( 'plugins_loaded', array( $this, 'init' ) );
  }
  /**
  * Initialize the plugin.
  */
 public function init() {
    // Checks if WooCommerce is installed.
    if ( class_exists( 'WC_Integration' ) ) {
      // Include our integration class.
      include_once 'integration.php';
      // Register the integration.
      add_filter( 'woocommerce_integrations', array( $this, 'add_integration' ) );
    }
 }
  /**
   * Add a new integration to WooCommerce.
   */
  public function add_integration( $integrations ) {
    $integrations[] = 'WC_My_plugin_Integration';
    return $integrations;
  }
}
$WC_custom_integration = new WC_custom_integration( __FILE__ );
endif;